<html>
	<head>
		<link rel="shortcut icon" href="img/ammo.png" type="image/png">
		<meta charset="UTF-8">
		<title>BASE</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
				<center>
					<h1 id="cu" style="font-size:50px">Traumatic Weapon</h1>
					<?php
						tt('travm');
					?>	
				</center>
			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>