<?php
	echo "<h1 style='color:white'>Thank you for order. We will call to you in 10 minutes</h1>";
	session_start();
	include 'connection.php';
	$v=$_SESSION['login'];
	$query = "SELECT * FROM users WHERE LOGIN='".$v."'";
	$result=mysql_query($query);
	$res=mysql_fetch_array($result);
	if($res!=''){
		$str='';
		$aa=$_SESSION['products'];
			if($aa!=''){	
			foreach($aa as $v){
				$str=$str." ".$v;
			}
		$query="INSERT INTO `buys`(`LOGIN`, `BUYS`) VALUES ('".$res[1]."','".$str."')";
		$result=mysql_query($query);
	}}
	$_SESSION['products']='';
	include 'profile.php';
?>