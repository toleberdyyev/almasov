<html>
	<head>
		<link rel="shortcut icon" href="img/ammo.png" type="image/png">
		<meta charset="UTF-8">
		<title>BASE</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
				<center>
				<br><br>
				<form method="POST" action="login.php">
					<a id="cuh">ВХОД</a>
					<br><br>
					<a id="cu">ЛОГИН:</a>
					<input name='login' id='login' placeholder="login" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;"></input>
					<br><br>
					<a id="cu">Пароль:</a>
					<input name='password' id='password' type="password" placeholder="password" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;"></input>
					<br>
					<input type="submit" value="ВОЙТИ" style="height:25px;width:85px;border-radius:10px 10px 10px 10px;margin-top:10px;margin-left:50px;"></input>
					<br>
					<!--<div class="xuy"><a href="#">Забыли пароль?</a></div>-->
				</form>
				</center>
			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>