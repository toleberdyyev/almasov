<html>
	<head>
		<link rel="shortcut icon" href="img/ammo.png" type="image/png">
		<meta charset="UTF-8">
		<title>BASE</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
				<center>
					<h1 id="cuh">AMMO.KZ</h1>
					<h2 style="color:white;">Web-shop AMMO present you big choices of Fire/Pneumatic/Traumatic/Defence Weapons and Accessories</h2>
					<h2 style="color:#BBBBBB;"> Контакты: </h2><h2 style="color:white;"> 8-701-608-11-65 </h2>
					<h2 style="color:#BBBBBB;"> e-mail: </h2><h2 style="color:white;">ammo.kz_@gmail.com</h2>
					<br>
					<p style="color:white;">Shop locates in the Departments Store 1st floor<br><img src='img/map.jpg'>
				</center>
			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>