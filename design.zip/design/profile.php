<html>
	<head>
		<link rel="shortcut icon" href="img/ammo.png" type="image/png">
		<meta charset="UTF-8">
		<title>AMMO</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
					<form method="POST" action="passchange.php">
					<a id="cuh">PROFILE</a>
					<br><br>
					<a id="cu">PRESENT PASWORD:</a>
					<input name="pas1" id="pas1" placeholder="password" type="password" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;"></input>
					<br><br>
					<a id="cu">NEW PASSWORD:</a>
					<input name="pas2" id="pas2" type="password" placeholder="password" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;"></input>
					<br>
					<input type="submit" value="CHANGE" style="height:25px;width:85px;border-radius:10px 10px 10px 10px;margin-top:10px;margin-left:50px;"></input>
					<br>
					</form>
					<!--<div class="xuy"><a href="#">Забыли пароль?</a></div>-->
					<?php
					echo "<h1>CHOOSED PRODUCTS</h1><br>";
					prod();
					echo "<br><br><form action='cleanp.php'>
						<br><br><input type='submit' style='border-radius:10px 10px 10px 10px; width:70px; height:40px;' value='clean'/>
					</form>";
					echo "<br><br><form action='buy.php'>
						<br><br><input type='submit' style='border-radius:10px 10px 10px 10px; width:70px; height:40px;' value='buy'/>
					</form>";
				?>
			</div>
			<div id="las">
					<br><br>
					<br><br>
					<br><br>
					<br><br>
			</div>
	</center>
	</body>
</html>