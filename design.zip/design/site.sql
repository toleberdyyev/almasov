-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 21 2016 г., 08:35
-- Версия сервера: 10.0.17-MariaDB
-- Версия PHP: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `site`
--

-- --------------------------------------------------------

--
-- Структура таблицы `buys`
--

CREATE TABLE `buys` (
  `LOGIN` varchar(50) NOT NULL,
  `BUYS` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `buys`
--

INSERT INTO `buys` (`LOGIN`, `BUYS`) VALUES
('qwe', ' 1 6 10'),
('qwe', ' 2 2 7 10 12 12 12 12 12'),
('qwe', ' 1 6 7');

-- --------------------------------------------------------

--
-- Структура таблицы `kor`
--

CREATE TABLE `kor` (
  `IDP` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `kor`
--

INSERT INTO `kor` (`IDP`) VALUES
(0),
(0);

-- --------------------------------------------------------

--
-- Структура таблицы `korz`
--

CREATE TABLE `korz` (
  `ID` int(11) NOT NULL,
  `IDP` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `PRICE` varchar(50) NOT NULL,
  `IMG` varchar(50) NOT NULL,
  `INFO` varchar(400) DEFAULT NULL,
  `TYPE` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`ID`, `NAME`, `PRICE`, `IMG`, `INFO`, `TYPE`) VALUES
(1, 'Revolver', '35000', 'img/revpis.jpg', 'TAURUS steel 9mm RA', 'travm'),
(2, 'GAMO', '55000', 'img/gamo.jpg', 'CFR Whisper Royal k.4,5', 'pnevm'),
(4, 'AK-47', '225000', 'img/ak47.jpeg', 'Carbine Saiga-MK cal. 223 Rem', 'fire'),
(5, 'FORT 12R', '105000', 'img/fort.jpe', '"FORT", Ukraine cal. 9mm', 'fire'),
(6, 'Ecol Firat Magnum', '105000', 'img/ecol.jpg', 'Turkey, 9mm RA', 'fire'),
(7, 'Gaz baloon Chilly', '1400', 'img/per.jpeg', '65.25 ml, Russia', 'gaz'),
(9, 'Borner "C-11"', '22000', 'img/bor.jpg', 'cal 4.5, CO2', 'pnevm'),
(10, 'Holster', '5000', 'img/acss.png', 'Leather Holster', 'acss'),
(11, 'M4a1', '320000', 'img/m4.jpg', 'M4a1, USA, cal. 9mm ', 'fire'),
(12, 'TEC-9', '90000', 'img/Tec9.png', 'Tec-9 pistol, cal. 9mm', 'fire'),
(13, 'Fort 17', '52000', 'img/fort17.jpg', 'Fort 17, caoutchouc bullets, cal. 9mm', 'travm');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `ID` int(15) NOT NULL,
  `LOGIN` varchar(52) NOT NULL,
  `PASSWORD` text NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `SURNAME` varchar(50) NOT NULL,
  `DAD` varchar(50) NOT NULL,
  `PHONE` varchar(50) NOT NULL,
  `AGE` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`ID`, `LOGIN`, `PASSWORD`, `NAME`, `SURNAME`, `DAD`, `PHONE`, `AGE`) VALUES
(1, 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 12),
(2, 'lordtemich', '12345', 'Temir', 'Almassov', 'Daulet', '+77017000154', 17),
(3, 'Temir', '12345', 'Temirlam', 'Almassov', 'Dauletovi4', '+7015263898', 55),
(4, 'alish', '25021998', 'alish', 'aba', 'almas', '87987465564', 5);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `korz`
--
ALTER TABLE `korz`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `korz`
--
ALTER TABLE `korz`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
