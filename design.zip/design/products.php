<?php
	include 'connection.php';
	//session_start();
	$query = "SELECT * FROM products WHERE 1";
	$result=mysql_query($query);
	while($row= mysql_fetch_assoc($result)){
		echo "<div class='rev'>";
		echo '<b style="float:left;color:red;margin-left:3px;margin-top:3px;">';
		echo $row['PRICE']." tg</b>";
		echo '<a href="?id='.$row['ID'].'" align="center"><img src="img/kor.jpg" width="20" height="20"/></a><br>';
		echo '<img src="'.$row['IMG'].'" width="150" height="145"/><br>';
		echo '<a>'.$row['NAME'].'</a><br>
					<a>'.$row['INFO'].'</a>';
	echo "</div>";}
		if(isset($_SESSION['login']))
		if($_SESSION['login']!=''){
			if(isset($_GET['id'])){
				if(isset($_SESSION['products'][0])){
				array_push($_SESSION['products'],$_GET['id']);}
				else{
					$_SESSION['products']=array($_GET['id']);
				}
			}
		}
	//http://localhost/design/vhod.php?login=mr.smile.dias%40mail.ru&password=12345
?>