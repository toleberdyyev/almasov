<html>
	<head>
		<link rel="shortcut icon" href="img/ammo.png" type="image/png">
		<meta charset="UTF-8">
		<title>BASE</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
					<br><br><br>
					<table style="margin-top:100px;">
						<tr>
							<img src="img/ogo.png" width="50" height="50"/>
							<a class="tab" href="fire.php">
								Fire Weapon
							</a>
							<img src="img/ogo.png" width="50" height="50"/>
						</tr><br>
						<tr>
							<img src="img/vozd.png" width="50" height="50"/>
							<a class="tab" href="pnev.php">
								Pneumatic Weapon
							</a>
							<img src="img/vozd.png" width="50" height="50"/>
						</tr><br>
						<tr>
							<img src="img/tram.png" width="50" height="50"/>
							<a class="tab" href="travm.php">Traumatic Weapon</a>
							<img src="img/tram.png" width="50" height="50"/>
						</tr><br>
						<tr>
							<img src="img/perc.png" width="50" height="50"/>
							<a class="tab" href="gaz.php">Defense Weapon</a>
							<img src="img/perc.png" width="50" height="50"/>
						</tr><br>
						<tr>
							<img src="img/acss.png" width="50" height="50"/>
							<a class="tab" href="acss.php">Accessories</a>
							<img src="img/acss.png" width="50" height="50"/>
						</tr><br>
					</table>
			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>