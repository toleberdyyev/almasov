<?php
session_start();
?>
<div id="upe">
				<div class="im">
					<img src="img/log.png" width="70" height="70"/>
				</div>
				<div class="ima">
					<a href="index.php">AMMO.kz</a>
				</div>
				<!-- <input type="search" name="q" placeholder="Поиск" id="sear"></input> -->
				<ul class="upen">
					<?php
						if(isset($_SESSION['login'])){
							if($_SESSION['login']!=''){
							echo '<li><a href="sclose.php"><b>LOG OUT</b></a></li>';
							echo '<li><a href="profile.php"><b>PROFILE</b></a></li>';
							}
							else{
								echo '<li><a href="regis.php"><b>SIGN IN</b></a></li>
					<li><a href="vhod.php"><b>LOG IN</b></a></li>';
							}
						}
						else{
							echo '<li><a href="regis.php"><b>SIGN IN</b></a></li>
					<li><a href="vhod.php"><b>LOG IN</b></a></li>';
						
						}
					?>
					<li><a href="cont.php"><b>CONTACTS</b></a></li>
				</ul>
</div>
 <div id="upe">
 <table>
						<tr>
							<img src="img/ogo.png" width="50" height="50"/>
							<a class="tab" href="fire.php">Fire</a>
							<img src="img/ogo.png" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/vozd.png" width="50" height="50"/>
							<a class="tab" href="pnev.php">
								Pneumatic
							</a>
							<img src="img/vozd.png" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/tram.png" width="50" height="50"/>
							<a class="tab" href="travm.php">Traumatic</a>
							<img src="img/tram.png" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/perc.png" width="50" height="50"/>
							<a class="tab" href="gaz.php">Defense</a>
							<img src="img/perc.png" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/acss.png" width="50" height="50"/>
							<a class="tab" href="acss.php">Accessories</a>
							<img src="img/acss.png" width="50" height="50"/>
						</tr>
	</table>
 </div>
<?php
	function prod(){
		include 'connection.php';
		if(isset($_SESSION['products'])){
			$aa=$_SESSION['products'];
			if($aa!=''){	
			foreach($aa as $v){
			$query = "SELECT * FROM products WHERE ID='".$v."'";
			$result=mysql_query($query);
			while($row= mysql_fetch_assoc($result)){
				echo "<div class='rev'>";
				echo '<b style="float:left;color:red;margin-left:3px;margin-top:3px;">';
				echo $row['PRICE']." tg</b>";
				echo '<a href="?id='.$row['ID'].'" align="center"><img src="img/kor.jpg" width="20" height="20"/></a><br>';
				echo '<img src="'.$row['IMG'].'" width="150" height="145"/><br>';
				echo '<a>'.$row['NAME'].'</a><br>
							<a>'.$row['INFO'].'</a>';
				echo "</div>";
		}
		}}}
	}
	function tt($t){
		include 'connection.php';
		$query = "SELECT * FROM products WHERE TYPE='".$t."'";
		$result=mysql_query($query);
		while($row= mysql_fetch_assoc($result)){
		echo "<div class='rev'>";
		echo '<b style="float:left;color:red;margin-left:3px;margin-top:3px;">';
		echo $row['PRICE']." tg</b>";
		echo '<a href="?id='.$row['ID'].'" align="center"><img src="img/kor.jpg" width="20" height="20"/></a><br>';
		echo '<img src="'.$row['IMG'].'" width="150" height="145"/><br>';
		echo '<a>'.$row['NAME'].'</a><br>
					<a>'.$row['INFO'].'</a>';
		echo "</div>";
		if(isset($_SESSION['login']))
		if($_SESSION['login']!=''){
			if(isset($_GET['id'])){
				if(isset($_SESSION['products'][0])){
				array_push($_SESSION['products'],$_GET['id']);}
				else{
					$_SESSION['products']=array($_GET['id']);
					$c=$_GET['id'];
				}
			}
		}
	}
	}
?>