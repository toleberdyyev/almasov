<?php
$error=0;
?>
<html>
	<head>
		<link rel="shortcut icon" href="img/ammo.png" type="image/png">
		<meta charset="UTF-8">
		<title>AMMO</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
				<?php
					include 'products.php';
				?>

			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>