<?php
	include 'connection.php';
	$error=0;
	$log=$_POST['login'];
	$pas=$_POST['password'];
	$pas1=$_POST['password1'];
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$surname=$_POST['surname'];
	$dad=$_POST['DAD'];
	$age=$_POST['age'];
	if($log=='' || $pas=='' || $pas1=='' || $name=='' || $surname=='' || $dad=='' || $age=='' || $pas!=$pas1){
		$error=1;
		header("Location:regis.php");
	}
	else{
		$query="INSERT INTO `users`(`LOGIN`, `PASSWORD`, `NAME`, `SURNAME`, `DAD`, `PHONE`, `AGE`) VALUES ('".$log."','".$pas."','".$name."','".$surname."','".$dad."','".$phone."','".$age."')";
		$res=mysql_query($query);
	}
?>